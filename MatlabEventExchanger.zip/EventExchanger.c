#include "mex.h"
#include <string.h>

#if defined(_WIN32)
    #include "include/hidapi.h"
    #define STRICMP _stricmp
#else
    #include <hidapi/hidapi.h>
    #define STRICMP strcasecmp
#endif

/// Global HID device handle
static hid_device *device = NULL;

/**
 * MEX gateway function for communicating with a HID device via HIDAPI.
 *
 * Supported commands:
 *   - EventExchanger('open', vid, pid)
 *   - EventExchanger('write', uint8_array)
 *   - EventExchanger('read')
 *   - EventExchanger('pulse', value, duration)
 *   - EventExchanger('clear')
 *   - EventExchanger('close')
 */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs < 1 || !mxIsChar(prhs[0])) {
        mexErrMsgTxt("First argument must be a command string.");
    }

    char cmd[64];
    mxGetString(prhs[0], cmd, sizeof(cmd));

    // === OPEN DEVICE ===
    if (STRICMP(cmd, "open") == 0) {
        if (nrhs < 3) {
            mexErrMsgTxt("Usage: EventExchanger('open', vid, pid)");
        }

        unsigned short vid = (unsigned short) mxGetScalar(prhs[1]);
        unsigned short pid = (unsigned short) mxGetScalar(prhs[2]);

        device = hid_open(vid, pid, NULL);
        if (!device) {
            mexErrMsgTxt("Failed to open HID device.");
        }

        hid_set_nonblocking(device, 1);  // Optional non-blocking reads
        mexPrintf("HID device opened (VID: 0x%04x, PID: 0x%04x)\n", vid, pid);
    }

    // === WRITE TO DEVICE ===
    else if (STRICMP(cmd, "write") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");
        if (nrhs < 2) mexErrMsgTxt("Usage: EventExchanger('write', uint8_array)");
        if (!mxIsUint8(prhs[1])) {
            mexErrMsgTxt("Second argument must be a uint8 array.");
        }

        size_t len = mxGetNumberOfElements(prhs[1]);
        unsigned char *data = (unsigned char *)mxGetData(prhs[1]);

        unsigned char buffer[65] = {0}; // HID reports use [0] = Report ID (usually 0)
        if (len > 64) len = 64;
        memcpy(buffer + 1, data, len);  // Offset by 1 for Report ID

        int res = hid_write(device, buffer, sizeof(buffer));
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === READ FROM DEVICE ===
    else if (STRICMP(cmd, "read") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");

        unsigned char buffer[64];
        int res = hid_read_timeout(device, buffer, sizeof(buffer), 1000); // 1 sec timeout

        if (res < 0) {
            mexErrMsgTxt("Read error.");
        }

        plhs[0] = mxCreateNumericMatrix(1, res, mxUINT8_CLASS, mxREAL);
        memcpy(mxGetData(plhs[0]), buffer, res);
    }

    // === PULSE COMMAND ===
    else if (STRICMP(cmd, "pulse") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");
        if (nrhs < 3) mexErrMsgTxt("Usage: EventExchanger('pulse', value, duration)");

        unsigned short value = (unsigned short) mxGetScalar(prhs[1]);
        unsigned short duration = (unsigned short) mxGetScalar(prhs[2]);

        unsigned char buffer[65] = {0};
        buffer[1] = 4;                    // Command ID for "pulse"
        buffer[2] = value;                // Pulse target value
        buffer[3] = duration & 0xFF;      // Duration LSB
        buffer[4] = (duration >> 8) & 0xFF; // Duration MSB

        int res = hid_write(device, buffer, sizeof(buffer));
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === CLEAR COMMAND ===
    else if (STRICMP(cmd, "clear") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");

        unsigned char buffer[65] = {0};
        buffer[1] = 0; // Command ID for "clear"

        int res = hid_write(device, buffer, sizeof(buffer));
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === CLOSE DEVICE ===
    else if (STRICMP(cmd, "close") == 0) {
        if (device) {
            hid_close(device);
            device = NULL;
            mexPrintf("HID device closed\n");
        }
    }

    // === UNKNOWN COMMAND ===
    else {
        mexErrMsgTxt(
            "Unknown command. Valid commands:\n"
            "  'open', 'write', 'read', 'pulse', 'clear', 'close'."
        );
    }
}
