/*
Compile for windows: 
    mex -lhidapi EventExchanger.c -Lx64
Compile for Linux:
    mex -lhidapi EventExchanger.c 

*/
#include "mex.h"
#include <string.h>
#include <wchar.h>

#if defined(_WIN32)
    #include <windows.h>
    #include "include/hidapi.h"
    #define STRICMP _stricmp
    #define strdup _strdup
#else
    #include <hidapi/hidapi.h>
    #define STRICMP strcasecmp
#endif

/// Global HID device handle
static hid_device *device = NULL;

/**
 * Helper function to convert wide string to UTF-8 string
 */
char* wide_to_utf8(const wchar_t* wide_str) {
    if (!wide_str) return strdup("");

    #if defined(_WIN32)
        int len = WideCharToMultiByte(CP_UTF8, 0, wide_str, -1, NULL, 0, NULL, NULL);
        if (len == 0) return strdup("");

        char* utf8_str = (char*)malloc(len);
        if (!utf8_str) return strdup("");

        WideCharToMultiByte(CP_UTF8, 0, wide_str, -1, utf8_str, len, NULL, NULL);
        return utf8_str;
    #else
        size_t len = wcstombs(NULL, wide_str, 0) + 1;
        char* utf8_str = (char*)malloc(len);
        if (!utf8_str) return strdup("");

        wcstombs(utf8_str, wide_str, len);
        return utf8_str;
    #endif
}

/**
 * Helper function to find the first device with 'EventExchanger' in the product string
 */
hid_device* find_event_exchanger_device() {
    struct hid_device_info *devs, *cur_dev;
    hid_device *device = NULL;

    devs = hid_enumerate(0x0, 0x0);
    cur_dev = devs;

    while (cur_dev) {
        char* product = wide_to_utf8(cur_dev->product_string);
        if (strstr(product, "EventExchanger") != NULL) {
            device = hid_open(cur_dev->vendor_id, cur_dev->product_id, NULL);
            free(product);
            break;
        }
        free(product);
        cur_dev = cur_dev->next;
    }

    hid_free_enumeration(devs);
    return device;
}

/**
 * MEX gateway function for communicating with a HID device via HIDAPI.
 *
 * Supported commands:
 *   - EventExchanger('open', vid, pid)
 *   - EventExchanger('write', uint8_array)
 *   - EventExchanger('read')
 *   - EventExchanger('pulse', value, duration)
 *   - EventExchanger('clear')
 *   - EventExchanger('close')
 *   - EventExchanger('list')
 */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs < 1 || !mxIsChar(prhs[0])) {
        mexErrMsgTxt("First argument must be a command string.");
    }

    char cmd[64];
    mxGetString(prhs[0], cmd, sizeof(cmd));

    // === LIST DEVICES ===
    if (STRICMP(cmd, "list") == 0) {
        struct hid_device_info *devs, *cur_dev;

        if (hid_init() != 0) {
            mexErrMsgTxt("Failed to initialize HIDAPI.");
        }

        devs = hid_enumerate(0x0, 0x0);
        if (!devs) {
            mexErrMsgTxt("No HID devices found.");
        }

        cur_dev = devs;

        // Count the number of devices
        int deviceCount = 0;
        while (cur_dev) {
            deviceCount++;
            cur_dev = cur_dev->next;
        }

        // Create field names for the struct array
        const char *field_names[] = {"DeviceName", "Path", "VendorID", "ProductID", "SerialNumber", "Manufacturer", "Product"};

        // Create a struct array to store device information
        plhs[0] = mxCreateStructMatrix(deviceCount, 1, 7, field_names);

        // Populate the struct array with device information
        cur_dev = devs;
        for (int i = 0; i < deviceCount; i++) {
            char deviceName[256];
            char* manufacturer = wide_to_utf8(cur_dev->manufacturer_string);
            char* product = wide_to_utf8(cur_dev->product_string);
            char* serial_number = wide_to_utf8(cur_dev->serial_number);

            snprintf(deviceName, sizeof(deviceName), "%s %s (VID: 0x%04x, PID: 0x%04x)",
                     manufacturer ? manufacturer : "Unknown",
                     product ? product : "Device",
                     cur_dev->vendor_id, cur_dev->product_id);

            mxSetFieldByNumber(plhs[0], i, 0, mxCreateString(deviceName));
            mxSetFieldByNumber(plhs[0], i, 1, mxCreateString(cur_dev->path));
            mxSetFieldByNumber(plhs[0], i, 2, mxCreateDoubleScalar(cur_dev->vendor_id));
            mxSetFieldByNumber(plhs[0], i, 3, mxCreateDoubleScalar(cur_dev->product_id));
            mxSetFieldByNumber(plhs[0], i, 4, mxCreateString(serial_number ? serial_number : "None"));
            mxSetFieldByNumber(plhs[0], i, 5, mxCreateString(manufacturer ? manufacturer : "Unknown"));
            mxSetFieldByNumber(plhs[0], i, 6, mxCreateString(product ? product : "Unknown"));

            free(manufacturer);
            free(product);
            free(serial_number);

            cur_dev = cur_dev->next;
        }

        hid_free_enumeration(devs);
        hid_exit();
    }

    // === OPEN DEVICE ===
    else if (STRICMP(cmd, "open") == 0) {
        if (nrhs < 2) {
            // Try to open the first device with 'EventExchanger' in the product string
            device = find_event_exchanger_device();
            if (!device) {
                mexErrMsgTxt("No HID device with 'EventExchanger' in the product string found.");
            }
        } else {
            unsigned short vid = (unsigned short)mxGetScalar(prhs[1]);
            unsigned short pid = (unsigned short)mxGetScalar(prhs[2]);

            device = hid_open(vid, pid, NULL);
            if (!device) {
                mexErrMsgTxt("Failed to open HID device.");
            }
        }

        hid_set_nonblocking(device, 1);  // Optional non-blocking reads
        mexPrintf("HID device opened\n");
    }

    // === WRITE TO DEVICE ===
    else if (STRICMP(cmd, "write") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");
        if (nrhs < 2) mexErrMsgTxt("Usage: EventExchanger('write', uint8_array)");
        if (!mxIsUint8(prhs[1])) {
            mexErrMsgTxt("Second argument must be a uint8 array.");
        }

        size_t len = mxGetNumberOfElements(prhs[1]);
        unsigned char *data = (unsigned char *)mxGetData(prhs[1]);

        unsigned char buffer[65] = {0}; // HID reports use [0] = Report ID (usually 0)
        if (len > 64) len = 64;
        memcpy(buffer + 1, data, len);  // Offset by 1 for Report ID

        int res = hid_write(device, buffer, sizeof(buffer));
        if (res < 0) {
            mexErrMsgTxt("Write error.");
        }
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === READ FROM DEVICE ===
    else if (STRICMP(cmd, "read") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");

        unsigned char buffer[64];
        int res = hid_read_timeout(device, buffer, sizeof(buffer), 1000); // 1 sec timeout

        if (res < 0) {
            mexErrMsgTxt("Read error.");
        }

        plhs[0] = mxCreateNumericMatrix(1, res, mxUINT8_CLASS, mxREAL);
        memcpy(mxGetData(plhs[0]), buffer, res);
    }

    // === PULSE COMMAND ===
    else if (STRICMP(cmd, "pulse") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");
        if (nrhs < 3) mexErrMsgTxt("Usage: EventExchanger('pulse', value, duration)");

        unsigned short value = (unsigned short)mxGetScalar(prhs[1]);
        unsigned short duration = (unsigned short)mxGetScalar(prhs[2]);

        unsigned char buffer[65] = {0};
        buffer[1] = 4; // Command ID for "pulse"
        buffer[2] = (unsigned char)value; // Ensure value fits in unsigned char
        buffer[3] = (unsigned char)(duration & 0xFF); // Duration LSB
        buffer[4] = (unsigned char)((duration >> 8) & 0xFF); // Duration MSB

        int res = hid_write(device, buffer, sizeof(buffer));
        if (res < 0) {
            mexErrMsgTxt("Pulse command write error.");
        }
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === CLEAR COMMAND ===
    else if (STRICMP(cmd, "clear") == 0) {
        if (!device) mexErrMsgTxt("Device not open.");

        unsigned char buffer[65] = {0};
        buffer[1] = 0; // Command ID for "clear"

        int res = hid_write(device, buffer, sizeof(buffer));
        if (res < 0) {
            mexErrMsgTxt("Clear command write error.");
        }
        plhs[0] = mxCreateDoubleScalar(res);
    }

    // === CLOSE DEVICE ===
    else if (STRICMP(cmd, "close") == 0) {
        if (device) {
            hid_close(device);
            device = NULL;
            mexPrintf("HID device closed\n");
        }
    }

    // === UNKNOWN COMMAND ===
    else {
        mexErrMsgTxt(
            "Unknown command. Valid commands:\n"
            "  'open', 'write', 'read', 'pulse', 'clear', 'close', 'list'."
        );
    }
}
