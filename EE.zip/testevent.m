% dotnetenv('core')
NET.addAssembly([pwd '\EventExchanger.dll']);
EE = ID.EventExchanger;
EE.Start();
EE.PulseEvent(255,100)